package sample;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

public class LoginCallBackHandler implements CallbackHandler {
	private String username;
    private char[] password;

    public LoginCallBackHandler() {
    	
    }
    public LoginCallBackHandler(String username, char[] password) {
        this.username = username;
        this.password = password;
    }

    public void handle(Callback[] callbacks) throws IOException,
            UnsupportedCallbackException {

        // We really know that the first callback is a NameCallback and that
        // the second callback is a PasswordCallback, but I am trying to show
        // how one might handle invalid callbacks
    	SampleLogin sm = new SampleLogin();
    	sm.invoke(sm);
    	this.username = sm.textField.getText();
        this.password = sm.passwordField.getText().toCharArray();       
        for (int i=0; i<callbacks.length; i++) {
            if (callbacks[i] instanceof NameCallback) {
                NameCallback nameCallback = (NameCallback) callbacks[i];
                nameCallback.setName(this.username);
            } else if (callbacks[i] instanceof PasswordCallback) {
                PasswordCallback passwordCallback = (PasswordCallback) callbacks[i];
                passwordCallback.setPassword(this.password);
            } else {
                throw new UnsupportedCallbackException(callbacks[i],
                        "Unrecognized Callback");
            }
        }
    }
}
