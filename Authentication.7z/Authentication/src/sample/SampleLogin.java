package sample;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import sample.LoginCallBackHandler;

//import org.authentication.controller.SwingLogin.LoginAction;


import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JDialog;

public class SampleLogin extends JFrame  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4010056150276677844L;
	 JPanel contentPane;
	 JTextField textField;
	 JPasswordField passwordField;
	 JButton btnLogin;
	 Container c;
	 JButton btnReg;
	static SampleLogin frame ;

	/**
	 * Launch the application.
	 */
	public static void invoke(SampleLogin fm) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = fm;
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SampleLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(53, 46, 63, 14);
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(152, 43, 208, 20);
		contentPane.add(textField);
		textField.setColumns(20);

		JLabel Password = new JLabel("Password");
		Password.setBounds(53, 85, 63, 14);
		contentPane.add(Password);

		passwordField = new JPasswordField();
		passwordField.setBounds(152, 82, 208, 20);
		contentPane.add(passwordField);
		passwordField.setColumns(20);

		btnLogin = new JButton("Login");
		btnLogin.setBounds(139, 166, 89, 23);
		btnLogin.setBackground(Color.orange);
		contentPane.add(btnLogin);

		//this.btnLogin.setAction( new LoginAction(this));
		this.btnLogin.addActionListener(new LoginAction(this));
		
		JLabel lblRole = new JLabel("Role");
		lblRole.setBounds(53, 122, 47, 14);
		contentPane.add(lblRole);

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(152, 119, 208, 20);
		contentPane.add(comboBox);

		JLabel lblNewUserRegister = new JLabel("New User Register Here");
		lblNewUserRegister.setBounds(53, 212, 124, 19);
		contentPane.add(lblNewUserRegister);

		btnReg = new JButton("Register");
        
		btnReg.setBounds(227, 210, 89, 23);
		btnReg.setBackground(Color.orange);
		contentPane.add(btnReg);
		this.btnLogin.addActionListener(new LoginAction(this));
		
		this.textField.requestFocus();
		this.passwordField.requestFocus();
		setResizable(false);
		setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);
		
		getRootPane().setDefaultButton(this.btnLogin);

	}

	private  class LoginAction extends AbstractAction{
		private JFrame owner;
		LoginCallBackHandler loginCallBackHandler;
		
        public LoginAction(JFrame owner) {
            super("Login");
            this.owner = owner;
        }
		
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
           String name =  textField.getText();
           String pwd =  passwordField.getText();
           System.out.println( name +" "+pwd);
           //loginCallBackHandler = new LoginCallBackHandler(name,pwd);
           SampleAcn acn = new SampleAcn();
          handle(name, pwd);

          
	}
	 CallbackHandler handler;
	public  void handle(String usr,String pwd) {

	      // Obtain a LoginContext, needed for authentication.
	      // Tell it to use the LoginModule implementation
	      // specified by the entry named "Sample" in the
	      // JAAS login configuration file and to also use the
	      // specified CallbackHandler.
	      LoginContext lc = null;
	      try {
	    	  handler = new LoginCallBackHandler(usr,pwd.toCharArray());
	          lc = new LoginContext("Sample",handler);
	      } catch (LoginException le) {
	          System.err.println("Cannot create LoginContext. "
	              + le.getMessage());
	          System.exit(-1);
	      } catch (SecurityException se) {
	          System.err.println("Cannot create LoginContext. "
	              + se.getMessage());
	          System.exit(-1);
	      }

	      // the user has 3 attempts to authenticate successfully
	      int i;
	      for (i = 0; i < 3; i++) {
	          try {

	              // attempt authentication
	              lc.login();

	              // if we return with no exception,
	              // authentication succeeded
	              break;

	          } catch (LoginException le) {

	              System.err.println("Authentication failed:");
	              System.err.println("  " + le.getMessage());
	              try {
	                  Thread.currentThread().sleep(3000);
	              } catch (Exception e) {
	                  // ignore
	              }

	          }
	      }

	      // did they fail three times?
	      if (i == 3) {
	          System.out.println("Sorry");
	          System.exit(-1);
	      }

	      System.out.println("Authentication succeeded!");

	    }
	
	
	}

	
	private class RegisterAction extends AbstractAction {

		private JFrame owner;
		LoginCallBackHandler loginCallBackHandler;
		
        public RegisterAction(JFrame owner) {
            super("Login");
            this.owner = owner;
        }
		
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
           String name =  textField.getText();
           String pwd =  passwordField.getText();
           System.out.println( name +" "+pwd);
          // AbstractAction
	  }
		
		
		
	}
}
